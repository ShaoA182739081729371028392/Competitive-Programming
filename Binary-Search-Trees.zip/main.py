# Binary Search Trees
class BSTNode():
  '''
  This Class Allows for the storage of necessary values for the BST Tree
  '''
  def __init__(self):
    self.value = None
    self.parent = None
    self.left = None # Less than OR equal to
    self.right = None # STRICTLY Greater than 
    # These values will be filled in
class BST():
  def __init__(self):
    self.root = None
  def search(self, value):
    '''
    Binary Search, just returns whether or not the value is present in the tree
    '''
    if self.root == None:
      return False
    cur_node = self.root
    while cur_node.left != None or cur_node.right != None:
      if value == cur_node.value:
        return True
      elif value > cur_node.value:
        if cur_node.right == None:
          return False
        cur_node = cur_node.right
      else:
        if cur_node.left == None:
          return False
        cur_node = cur_node.left
    if cur_node.value == value:
      return True
    return False
  def insert(self, value):
    new_node = BSTNode()
    new_node.value = value
    if self.root == None:
      self.root = new_node
      return
    cur_node = self.root
    while cur_node.left != None or cur_node.right != None:
      if new_node.value > cur_node.value:
        if cur_node.right == None:
          cur_node.right = cur_node
          return 
        else:
          cur_node = cur_node.right
      else:
        if cur_node.left == None:
          cur_node.left = new_node
          return
        cur_node = cur_node.left
    if new_node.value > cur_node.value:
      cur_node.right = new_node
    else:
      cur_node.left = new_node
  def in_order_stack(self):
    '''
    Uses a stack to perform in order traversal
    '''
    if self.root == None:
      print("The BST is empty. Returning")
      return
    stack = Stack()
    cur_node = self.root
    while not stack.empty():
      if cur_node != None:
        while cur_node.left != None:
          stack.stack(cur_node)
          cur_node = cur_node.left
      cur_node = stack.destack()
      print(cur_node.value)
      cur_node = cur_node.right 
      
  def in_order_print(self):
    '''
    Traverses through the Binary Tree Recursively, printing values in order
    '''
    if self.root == None:
      print("no nodes in tree, returning")
      return
    self.recursion_step_in_order_print(self.root)
  def recursion_step_in_order_print(self, node):
    if node.left == None and node.right == None:
      print(node.value)
      return
    else:
      if node.left != None:
        self.recursion_step_in_order_print(node.left)
      print(node.value)
      if node.right != None:
        self.recursion_step_in_order_print(node.right)
class Stack():
  '''
  Replaces Recursion in an inorder traversal of the binary tree
  '''
  def __init__(self):
    self.stack = []
  def stack(self, val):
    self.stack += [val]
  def destack(self):
    val = self.stack[-1]
    self.stack = self.stack[:-1]
    return val
  def empty(self):
    return len(self.stack) == 0
bstTree = BST()
bstTree.insert(1)
bstTree.insert(2)
bstTree.insert(0)
bstTree.insert(4)
#simple Search
#set_trace()
bstTree.in_order_stack()